/**
 * Created by NiGhTy on 2014.04.23..
 */
(function() {

    "use strict";

    awaxa.sentinel.models.Mode = awaxa.sentinel.models.Mode ||
    {
        BEGINNER : {
            label : 'MODE_BEGINNER',
            value : 0
        },
        EXPERT : {
            label : 'MODE_EXPERT',
            value : 1
        }
    };

}());