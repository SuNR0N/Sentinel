/**
 * Created by NiGhTy on 2014.04.15..
 */
(function() {

    "use strict";

    window.awaxa = window.awaxa || {};
    window.awaxa.sentinel = window.awaxa.sentinel || {};
    window.awaxa.sentinel.configs = window.awaxa.sentinel.configs || {};
    window.awaxa.sentinel.controllers = window.awaxa.sentinel.controllers || {};
    window.awaxa.sentinel.directives = window.awaxa.sentinel.directives || {};
    window.awaxa.sentinel.filters = window.awaxa.sentinel.filters || {};
    window.awaxa.sentinel.models = window.awaxa.sentinel.models || {};
    window.awaxa.sentinel.services = window.awaxa.sentinel.services || {};

}());