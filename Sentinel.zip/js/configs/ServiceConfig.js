/**
 * Created by NiGhTy on 2014.04.15..
 */
(function(){

    "use strict";

    awaxa.sentinel.configs.ServiceConfig = awaxa.sentinel.configs.ServiceConfig ||
    {
        rootURL : '/ClientManager/service'
    };

}());